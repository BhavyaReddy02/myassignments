package program1;

public class InputMismatchException extends Exception {

	@Override
	public String toString() {
		String Message = "java.util.InputMismatchException occurs!!!!";
		return Message;
	}
	
}
