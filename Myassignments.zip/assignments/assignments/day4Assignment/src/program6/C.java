package program6;

public class C extends B {
    private int a = 543;
    public void display() {
        System.out.printf("a in C = %d\n", a);
    }

}
