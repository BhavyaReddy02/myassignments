package program6;

public class B extends A {
    private int a = 123;
    public void display() {
        System.out.printf("a in B = %d\n", a);


}
}