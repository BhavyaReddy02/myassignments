package program6;

public class A {
	int a = 100;
    public void display() {
        System.out.printf("a in A = %d\n", a);

    }
}
