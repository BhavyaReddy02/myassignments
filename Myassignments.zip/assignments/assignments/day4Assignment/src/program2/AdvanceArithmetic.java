package program2;

public interface AdvanceArithmetic {
	public int divisorSum(int n);
}
