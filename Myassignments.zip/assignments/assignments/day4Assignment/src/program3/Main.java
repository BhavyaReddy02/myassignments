package program3;

public class Main {

	public static void main(String[] args) {
		MembershipCard membershipCard = new MembershipCard("kashyap", "1234", "20/08/2070", 4);
		PaybackCard paybackCard = new PaybackCard("kjskjbd", "2983094", "19/1980", 50, 4800.00);
		System.out.println(membershipCard);
		System.out.println(paybackCard);

	}

}
