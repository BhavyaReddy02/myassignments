package program8;

public class InheritanceExample {

	public static void main(String[] args) {
		Dog dog =new Dog();
		dog.walk();
		dog.eat();
		dog.bark();
	}

}
