package program8;
/*
 * Consider the below code and you must add a �bark method to the Dog class, then modify the main method accordingly so that the code prints the following lines:
I am walking
I am eating
I am barking

 */
public class Animal {
	void walk(){
		System.out.println("I am walking");
	}
}
