package program8;

public class Dog extends Animal {
	void eat(){
		System.out.println("I am eating");
	}
	void bark(){
		System.out.println("I am barking");
	}
}
