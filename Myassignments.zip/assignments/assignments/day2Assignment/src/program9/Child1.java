package program9;
//Find the output of the following code snippet:
public class Child1 extends Parent {

}
