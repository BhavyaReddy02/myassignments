package program9;

public class Child2 extends Parent {

}
