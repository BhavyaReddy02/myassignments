package program5;

public class MainClass {

	public static void main(String[] args) {
		ClassB classB = new ClassB();
		System.out.println(classB.displayB());
		System.out.println(classB.display());
	}

}
