package program5;
//Create class named as �a� and create a sub class �b�. Which is extends from class �a�. 
//And use these classes in �inherit� class.
public class ClassA {
	private String string;

	public String display() {
		string = "I'm from classA";
		return string;
	}

}
