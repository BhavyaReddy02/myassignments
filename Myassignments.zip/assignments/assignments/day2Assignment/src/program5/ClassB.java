package program5;

public class ClassB extends ClassA {
	public String stringB;
	public String displayB(){
		stringB= "I'm from B";
		return stringB;
	}
}
