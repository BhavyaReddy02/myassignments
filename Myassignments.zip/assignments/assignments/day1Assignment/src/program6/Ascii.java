package program6;
//Write a Java program to print the ascii value of a given character. 
public class Ascii {
	public int value(char charecter){
		int asciivalue = charecter;
		return asciivalue;
	}

}
