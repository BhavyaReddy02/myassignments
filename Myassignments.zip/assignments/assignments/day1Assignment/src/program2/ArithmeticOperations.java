package program2;
/*
 *2.	Write a Java program to print the sum (addition), multiply, subtract, divide and remainder of two numbers. 

Test Data:
Input first number: 20
Input second number: 4
 */
public class ArithmeticOperations {
	public int addittion(int number1, int number2){
		return number1+number2;
	}
	public int subtraction(int number1, int number2){
		return number1+number2;
	}
	public int multiplication(int number1, int number2){
		return number1+number2;
	}
	public float division(int number1, int number2){
		return number1/number2;
	}
	public int remainder (int number1, int number2){
		return number1%number2;
	}

}
