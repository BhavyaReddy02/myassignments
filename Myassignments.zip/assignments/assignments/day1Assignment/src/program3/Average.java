package program3;
/*
 * Write a Java program that takes three numbers as input to calculate and print the  average of the numbers.
 */
public class Average {
	public float averagenumber(int number1, int number2, int number3) {
		return (number1 + number2 + number3) / 3.0f;
	}

}
